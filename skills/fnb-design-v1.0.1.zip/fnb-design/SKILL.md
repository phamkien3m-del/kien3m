---
name: fnb-design
description: Thiết kế nhận diện, menu, bao bì, bài đăng mạng xã hội và video quảng cáo món ăn/đồ uống cho nhà hàng, quán cà phê, trà sữa, tiệm bánh và thương hiệu thực phẩm. Dùng khi cần tạo hoặc cải tiến thiết kế F&B, phát triển concept, storyboard, video ngắn, phụ đề hay bộ file bàn giao. Tạo đầu ra cụ thể bằng công cụ sẵn có; không dừng ở lời khuyên hoặc prompt khi có thể thực hiện.
---

# Thiết kế F&B

## Mục tiêu và phạm vi

Biến yêu cầu kinh doanh thành thiết kế dễ nhận diện, dễ đọc và giúp khách chọn món hoặc thực hiện hành động mong muốn. Mặc định làm việc bằng tiếng Việt, giữ đúng ngôn ngữ của thương hiệu khi được cung cấp.

Phạm vi chính: nhận diện thương hiệu, menu, bao bì, bài đăng mạng xã hội và video quảng cáo F&B. Thiết kế không gian và hồ sơ kỹ thuật sản xuất chuyên ngành không nằm trong phạm vi chuyên sâu của skill này.

## 1. Đọc brief và chọn đầu ra

- Đọc yêu cầu, tài liệu thương hiệu và tài nguyên người dùng đã cung cấp trước khi hỏi thêm. Nếu có đường dẫn hoặc tệp, dùng công cụ phù hợp để xem nội dung thực tế.
- Xác định: loại hình F&B; khách hàng chính; mục tiêu; đầu ra/kênh; tên thương hiệu; nội dung bắt buộc; tài nguyên hiện có; kích thước và hạn chế sản xuất.
- Dùng [mẫu brief](templates/brief.md) khi cần gom thông tin. Không bắt người dùng điền toàn bộ mẫu cho một yêu cầu nhỏ.
- Chỉ hỏi các câu còn thiếu ảnh hưởng trực tiếp đến kết quả. Có thể gộp tối đa ba câu ngắn. Tiếp tục phần độc lập trong khi chờ.
- Khi thiếu sở thích thẩm mỹ, chọn một hướng hợp lý và nói rõ giả định. Với thông tin thực tế như giá, ưu đãi, địa chỉ, thành phần hoặc QR, dùng chỗ giữ `[CẦN XÁC NHẬN: ...]`; không tự bịa cho bản có thể phát hành.
- Nếu người dùng chưa chọn loại đầu ra, mặc định đề xuất một key visual mạng xã hội cho món chủ lực. Nếu chưa có dữ liệu thương hiệu/món, tạo concept minh họa và ghi rõ đó là dữ liệu giả định.
- Nếu yêu cầu video, xác định thêm thời lượng, tỷ lệ khung, nguồn footage, giọng đọc/âm nhạc và phụ đề. Nếu chưa nêu, có thể chọn video dọc 15 giây, 1080 × 1920, 30 fps và ghi rõ đây là mặc định để triển khai.

## 2. Chốt hướng thiết kế bằng lý do cụ thể

Với yêu cầu đơn giản, chọn một hướng và triển khai. Với bộ nhận diện hoặc yêu cầu khám phá, trình bày hai hướng khác nhau về bố cục, hình ảnh và kiểu chữ; khuyến nghị một hướng gắn với khách hàng và mục tiêu. Không bắt buộc chờ phê duyệt giữa các bước nếu người dùng đã giao làm trọn gói.

Mỗi hướng cần xác định:

- Một ý tưởng chính và cảm giác cần tạo ra, ví dụ “tiệm bánh thủ công buổi sáng” thay vì chỉ “cao cấp”.
- Màu nền, màu chữ, màu nhấn và vai trò sử dụng của chúng.
- Một hoặc hai họ chữ hỗ trợ tiếng Việt; kiểm tra dấu trên tiêu đề, giá và cỡ chữ nhỏ.
- Cách xử lý ảnh món: góc chụp, ánh sáng, phông nền, tỷ lệ sản phẩm và khoảng trống cho chữ.
- Thứ tự đọc: món/thương hiệu → lợi ích hoặc thông tin chính → giá/chi tiết → hành động.

Ưu tiên đặc tính thật của thương hiệu. Tránh áp một bộ màu, font, nền gradient hay bố cục mặc định cho mọi nhà hàng/quán.

## 3. Tạo thiết kế bằng công cụ hiện có

Đọc phần tương ứng trong [quy cách đầu ra](references/deliverables.md). Chỉ đọc các mục cần cho yêu cầu hiện tại.

Với video, đọc thêm [quy trình video](references/video-workflow.md), lập [storyboard](templates/storyboard.md), rồi dựng và xuất video thực tế nếu công cụ hỗ trợ. Chỉ dừng ở kịch bản/storyboard khi đó là đầu ra được yêu cầu hoặc có giới hạn công cụ/tài nguyên đã nêu rõ. Với bộ chiến dịch gồm ảnh và video, dùng chung thông điệp, món chủ lực, màu, chữ và CTA nhưng điều chỉnh bố cục theo từng định dạng.

- Dùng công cụ thiết kế/tệp có sẵn để tạo bản thực tế. Với hình cần tạo hoặc chỉnh sửa, dùng công cụ tạo/chỉnh sửa ảnh nếu có; giữ ảnh tham chiếu và chi tiết sản phẩm theo yêu cầu.
- Khi công cụ tạo ảnh yêu cầu bắt đầu trực tiếp, tự tổng hợp brief từ dữ liệu hiện có và làm ngay. Không thêm bước xác nhận hình thức.
- Giữ các nội dung cần chính xác như tên món, giá, hotline, địa chỉ và QR ở lớp chữ/vector có thể kiểm soát khi công cụ cho phép. Kiểm tra lại mọi chữ được tạo bên trong ảnh.
- Dùng [mẫu prompt hình ảnh](templates/image-direction.md) để mô tả art direction, không dùng nó thay cho đầu ra thiết kế nếu có công cụ tạo được file.
- Nếu thiếu khả năng xuất định dạng yêu cầu, tạo định dạng hữu ích thực hiện được, kèm thông số và nêu rõ giới hạn. Không đặt đuôi `.ai`, `.psd` hay `.pdf` lên một tệp khác định dạng.
- Với sản phẩm thật, giữ đúng kích thước tương đối, màu sắc, thành phần nhìn thấy và kiểu bao bì. Nếu chỉ có ảnh minh họa, ghi rõ trong bàn giao; đừng mô tả là ảnh sản phẩm đã chụp.
- Khi cần bộ nhận diện nhiều đầu ra, tạo bảng màu, typography, khoảng cách và quy tắc hình ảnh dùng chung trước, rồi áp dụng nhất quán. Ưu tiên logo và kích thước/tỷ lệ gốc do người dùng cung cấp.
- Lưu bản nháp ở thư mục đầu ra riêng; không ghi đè tài nguyên nguồn. Không đăng bài, gửi file cho khách/nhà in hoặc đặt sản xuất nếu chưa được yêu cầu.

## 4. Kiểm tra bản thực tế và sửa

Mở hoặc render tệp đã tạo bằng công cụ xem tương ứng; kiểm tra ở kích thước sử dụng. Dùng [checklist đánh giá](references/review-checklist.md), sửa lỗi nhìn thấy rồi kiểm tra lại phần đã sửa.

Các điểm bắt buộc: thứ tự đọc; chữ tiếng Việt; tên món và giá; độ tương phản; món ăn đúng brief; logo không biến dạng; ảnh không bị kéo méo; nội dung không cắt mất; file đúng kích thước/định dạng. Kiểm tra QR bằng giải mã nếu có; không tạo một hoa văn trông giống QR rồi coi là hoạt động.

Với video, kiểm tra cả đầu/cuối và các điểm chuyển cảnh, thời gian đọc chữ, đồng bộ phụ đề, âm thanh và tổng thời lượng. Phân biệt kiểm tra kỹ thuật bằng giải mã với việc đã xem/nghe nội dung; chỉ báo những bước thực sự thực hiện được.

Phân biệt ba mức:

- **Đã kiểm tra:** có bằng chứng từ việc mở, render, đo kích thước hoặc kiểm tra dữ liệu.
- **Chờ xác nhận nội dung:** còn placeholder, thông tin chưa xác thực hoặc thiếu tài nguyên.
- **Chờ kiểm tra sản xuất:** còn phụ thuộc dieline, chất liệu, profile màu, in thử hoặc yêu cầu nhà cung cấp.

Không gọi mockup bao bì là file sẵn sàng in. Không tuyên bố tăng doanh thu, đã kiểm thử trên thiết bị, đã xác minh bản quyền hay đã đạt tiêu chuẩn kỹ thuật khi chưa có bằng chứng.

## 5. Bàn giao gọn và dùng được

Dùng [mẫu bàn giao](templates/handoff.md) khi có nhiều tệp. Với một thiết kế nhỏ, trả lời ngắn hơn nhưng vẫn có đường dẫn tới file và nêu vấn đề còn chờ.

Bàn giao gồm: bản xem, file nguồn thực tế nếu có, file xuất phù hợp, thông số chính và trạng thái kiểm tra. Nêu hướng thiết kế bằng một hoặc hai câu, không lặp lại toàn bộ quá trình.

Nếu có nhiều phiên bản, dùng tên rõ như `<thuong-hieu>_<dau-ra>_<kich-thuoc>_v01.<duoi-tep>`. Không để dữ liệu minh họa hoặc placeholder lẫn vào bản được mô tả là hoàn tất.
