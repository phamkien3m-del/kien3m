# Yêu cầu thử nghiệm

Toàn bộ tên thương hiệu, sản phẩm và giá dưới đây là dữ liệu hư cấu phục vụ thử skill.

## Thiết kế bài đăng

> Dùng skill fnb-design tạo một bài đăng 1080 × 1350 px cho quán cà phê hư cấu “Mây Sớm”. Món chủ lực: “Cà phê sữa đá”, giá mẫu 35.000đ. Khách hàng là người đi làm thích không gian bình dị và cà phê Việt. Phong cách ấm, thoáng, gần gũi; tránh nền đen và chi tiết trang trí rối. Nội dung chính: “Một ngụm cà phê, bắt đầu ngày mới.” CTA: “Khám phá hương vị Mây Sớm”. Chưa có logo, dùng tên quán dạng chữ trong concept, không mô tả là logo thương hiệu đã hoàn thiện. Dùng ảnh món minh họa, không thêm chứng nhận hay ưu đãi. Tạo file xem được bằng công cụ hiện có; đặt dòng “CONCEPT MINH HỌA” nhỏ nhưng đọc được ở mép dưới. Bàn giao file, giải thích ngắn hướng thiết kế và kết quả kiểm tra.

## Dấu hiệu thực hiện đúng

- Tạo file thật nếu có công cụ phù hợp; nếu thiếu công cụ, nói rõ giới hạn và chỉ bàn giao thứ đã tạo được.
- Giữ đúng tên món, giá và dấu tiếng Việt; không tự thêm địa chỉ, QR hay khuyến mãi.
- Thứ tự đọc rõ, món chủ lực nổi bật, chữ có tương phản tốt.
- File xuất đúng kích thước hoặc nêu rõ sai khác thực tế.
- Có bằng chứng đã mở/render để kiểm tra khi công cụ cho phép; không tự báo đã kiểm tra.
- Bản minh họa được nhận diện rõ và không bị trình bày như sản phẩm đã phát hành.

## Video quảng cáo

> Dùng skill fnb-design tạo video dọc 15 giây cho cùng thương hiệu hư cấu “Mây Sớm”, giới thiệu “Cà phê sữa đá”, giá mẫu 35.000đ. Giữ màu và chữ thống nhất với bài đăng nếu đã có. Đầu ra mong muốn: MP4 1080 × 1920, 30 fps. Chưa có footage, dùng hình minh họa do công cụ hiện có tạo hoặc tài nguyên minh họa được cung cấp; dựng từ ảnh có chuyển động nhẹ là phù hợp. Bản thử không cần nhạc hay giọng đọc. Chữ mở đầu: “Một ngụm cà phê, bắt đầu ngày mới.” Kết thúc bằng “Khám phá hương vị Mây Sớm”. Giữ nhãn “CONCEPT MINH HỌA” đọc được. Tạo storyboard rồi xuất video nếu công cụ cho phép; bàn giao MP4, project/composition thực tế nếu đã tạo và kết quả kiểm tra.

## Dấu hiệu thực hiện đúng cho video

- Có storyboard, nội dung các cảnh cùng hướng với bài đăng, không tự thêm chi tiết kinh doanh.
- Xuất file thật nếu có công cụ; đo thời lượng/khung hình/codec thay vì chỉ nêu thông số dự định.
- Kiểm tra khả năng giải mã, các cảnh, chuyển cảnh, thời gian đọc chữ và end card.
- Không có lời nói thì không tự tạo SRT được mô tả là transcript.
- Nếu không thể render, bàn giao phần đã hoàn thành và nêu khả năng thiếu; không coi storyboard là MP4 đã xuất.
