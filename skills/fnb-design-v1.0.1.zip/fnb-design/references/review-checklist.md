# Kiểm tra trước khi bàn giao

Chỉ áp dụng mục liên quan đến sản phẩm đang làm. Sửa lỗi có thể xử lý ngay; với dữ liệu còn thiếu, đánh dấu rõ trong bản nháp và phần bàn giao. Ghi đúng những kiểm tra đã thực hiện.

## Nội dung và món ăn

- [ ] Tên thương hiệu, tên món, giá, đơn vị, size, địa chỉ và thông tin liên hệ khớp nguồn người dùng cung cấp.
- [ ] Thời gian, điều kiện và phạm vi ưu đãi đã có nguồn xác nhận; không có lời quảng cáo hoặc số liệu tự tạo.
- [ ] Những trường chưa biết dùng chỗ giữ chỗ dễ nhận diện, không lẫn với dữ liệu thật.
- [ ] Ảnh giữ đúng loại món, nguyên liệu chính, khẩu phần và cách phục vụ đã mô tả. Ảnh minh họa được xác định trong bàn giao nếu có thể bị hiểu là ảnh món thực tế.
- [ ] Không suy ra “thuần chay”, “không gluten”, “không gây dị ứng”, thành phần dinh dưỡng hoặc công dụng sức khỏe chỉ từ ảnh hay tên món.

## Chữ tiếng Việt và khả năng đọc

- [ ] Font hiển thị đủ dấu tiếng Việt; không lỗi ký tự, dấu bị cắt hoặc thay font giữa câu.
- [ ] Kiểm tra chuỗi có nhiều dấu như “Cà phê sữa đá — Bún bò Huế — Ưu đãi cuối tuần” bằng chính font dùng trong thiết kế.
- [ ] Tiêu đề, tên món, mô tả và giá có thứ bậc rõ; không dùng quá nhiều kiểu chữ hoặc hiệu ứng gây cạnh tranh.
- [ ] Thử xem ở kích thước sử dụng thực: điện thoại với nội dung số, kích thước in thực hoặc tương đương với menu/nhãn.
- [ ] Thông tin quan trọng có tương phản đủ rõ. Nếu đo theo WCAG cho nội dung số, hướng tới ít nhất 4,5:1 cho chữ thường và 3:1 cho chữ lớn; ghi rõ khi chưa đo.
- [ ] Không dùng riêng màu sắc để phân biệt size, nhóm món hoặc điều kiện ưu đãi; có nhãn chữ hoặc ký hiệu hỗ trợ.

## Bố cục và tính nhất quán

- [ ] Người xem nhận ra món/thông điệp chính trước, rồi thấy hành động tiếp theo.
- [ ] Lề, khoảng cách, đường căn, cách viết giá và hệ thống màu thống nhất giữa các biến thể.
- [ ] Không có chữ tràn, ảnh méo, chi tiết quan trọng bị cắt hay nội dung bị che bởi giao diện khi áp dụng cho kênh số.
- [ ] Khi đổi tỷ lệ, bố cục đã được dàn lại và kiểm tra từng bản xuất.
- [ ] Logo và ảnh không bị kéo giãn, đổi nội dung hoặc giảm chất lượng ngoài chủ đích đã nêu.

## Tệp số và tệp in

- [ ] Mở được tệp đã xuất; kiểm tra kích thước, tỷ lệ, số trang, nội dung và độ nét của chính tệp đó.
- [ ] Tệp nguồn, ảnh tham chiếu và bản xuất được phân biệt rõ; không gọi tệp raster là vector hay ảnh mockup là khuôn bế.
- [ ] Với bản in, kiểm tra bleed, vùng an toàn, đường cắt/gấp, font, ảnh và màu theo thông số nhà in đã cung cấp.
- [ ] QR/đường dẫn được kiểm tra với đích đã xác nhận; nếu chưa thử quét bản in thực, nêu đúng giới hạn kiểm tra.
- [ ] Font và tài sản bên ngoài có nguồn và tình trạng quyền sử dụng được ghi đúng; không mặc định được phép sử dụng thương mại.

## Video và âm thanh

- [ ] Storyboard/shot list thể hiện đủ thời lượng từng cảnh, hình ảnh, chữ, âm thanh và CTA; nội dung món/đồ uống khớp brief.
- [ ] Tỷ lệ, độ phân giải, fps, thời lượng và codec được kiểm tra trên tệp xuất thực tế; chỉ nêu các định dạng công cụ đã tạo được.
- [ ] Xem và nghe trọn bản render; không có khung đen ngoài chủ đích, khung đứng bất thường, cảnh bị cắt lỗi hoặc chữ còn sót sau chuyển cảnh.
- [ ] Mốc bắt đầu/kết thúc của phụ đề và chữ khớp cảnh hoặc lời đọc; đủ thời gian đọc, không che món/giá/CTA quan trọng, không mất dấu tiếng Việt.
- [ ] Thông tin quan trọng tránh vùng giao diện có thể che trên kênh đích; kiểm tra lại khi chuyển tỷ lệ.
- [ ] Âm thanh rõ, không bị méo hoặc cắt đột ngột; nhạc không lấn lời đọc. Nguồn và tình trạng quyền dùng nhạc/lời đọc/hiệu ứng được ghi đúng.
- [ ] Giá, ưu đãi và lời quảng cáo trong lời đọc, phụ đề và hình ảnh thống nhất; không thêm cam kết hoặc số liệu chưa xác nhận.
- [ ] Tệp nguồn, media phụ thuộc, bản render và phụ đề được liệt kê đúng thực tế; nêu rõ tệp thiếu hoặc phần chưa thể xuất thay vì coi là hoàn tất.

## Báo cáo bàn giao

Báo ngắn gọn: đã tạo gì, các tệp ở đâu, dùng hoặc sửa thế nào, đã kiểm tra gì và dữ liệu nào còn cần xác nhận. Gắn trạng thái với từng đầu ra: bản nháp, mockup, bản xuất số đã kiểm tra hoặc bản chờ thông số nhà in. Chỉ xác nhận “sẵn sàng gửi in” khi đã thực hiện đủ kiểm tra sản xuất liên quan.
