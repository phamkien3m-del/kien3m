# Đầu ra thiết kế F&B

Chọn đúng nhóm đầu ra trong brief. Dùng các gợi ý dưới đây để hoàn thành sản phẩm có thể xem, sửa và bàn giao; không tự mở rộng một bài đăng thành cả bộ nhận diện. Kích thước là điểm xuất phát khi người dùng chưa có yêu cầu, cần điều chỉnh theo nơi sử dụng thực tế.

## Nhận diện thương hiệu

- Tóm tắt khách hàng mục tiêu, mức giá, trải nghiệm và lý do chọn hướng hình ảnh trong vài câu.
- Tạo bộ màu có mã HEX, vai trò từng màu và cặp màu chữ/nền dễ đọc. Chỉ bổ sung thông số màu in sau khi biết quy trình in.
- Chọn font có đủ dấu tiếng Việt; quy định tiêu đề, nội dung, giá và thông tin phụ. Ghi tên font, nguồn và điều kiện sử dụng đã xác minh; nếu chưa xác minh thì ghi rõ.
- Nếu có logo: tạo bản chính, bản một màu, bản dùng trên nền tối và kích thước nhỏ. Bàn giao vector chỉnh sửa được nếu công cụ cho phép; ảnh raster không được gọi là vector.
- Đưa hệ thống lên một ứng dụng cụ thể đúng brief, chẳng hạn mặt menu hoặc bài giới thiệu món. Logo, ảnh và tên thương hiệu do khách hàng cung cấp được giữ đúng nội dung.

## Menu

Thứ tự đọc nên làm rõ nhóm món, tên món, mô tả cần thiết, lựa chọn khẩu phần và giá. Dùng lưới và căn lề giá nhất quán; món nổi bật cần có lý do từ brief, không mặc định mọi món đều là “bán chạy”.

- Dùng danh sách món và giá của người dùng làm nguồn chuẩn; kiểm lại từng dòng sau dàn trang.
- Thống nhất cách viết tiền tệ, dấu phân cách và đơn vị. Ghi rõ giá áp dụng cho size hoặc khẩu phần nào.
- Không tự tạo giá, nguyên liệu, mức cay, thông tin ăn chay hoặc dị ứng. Dùng chỗ giữ chỗ rõ ràng như `[GIÁ CẦN XÁC NHẬN]` khi thiếu dữ liệu.
- Với menu nhiều trang, giữ tên nhóm và hệ thống giá nhất quán; kiểm tra món bị rơi sang trang hoặc mô tả bị cắt.
- Chọn định dạng theo sử dụng: A4/A5 chỉ là gợi ý cho bản in; menu điện thoại cần thử ở chiều rộng màn hình thật. PDF số cần văn bản đọc được và đường dẫn hoạt động nếu có.

Bàn giao bản xem trước, tệp nguồn chỉnh sửa được và bản xuất đúng mục đích. Nếu có chỗ giữ chỗ chưa được xác nhận, ghi “bản nháp” trong phần bàn giao.

## Bài đăng và quảng cáo số

Mỗi thiết kế cần một thông điệp chính, một điểm nhấn món/đồ uống và lời kêu gọi hành động phù hợp với mục tiêu. Dùng ảnh sản phẩm thực nếu có; khi tạo ảnh minh họa, thể hiện rõ đó là hình minh họa trong bàn giao và giữ nguyên đặc điểm món đã được cung cấp.

| Trường hợp | Kích thước gợi ý | Điều cần kiểm tra |
| --- | --- | --- |
| Bài vuông | 1080 × 1080 px | Tên món và ưu đãi đọc được trên điện thoại |
| Bài dọc | 1080 × 1350 px | Bố cục vẫn rõ khi xem thu nhỏ |
| Story hoặc khung video dọc | 1080 × 1920 px | Giữ thông tin quan trọng tránh vùng giao diện có thể che |

Đây là kích thước thiết kế phổ biến để bắt đầu, không phải cam kết thông số hiện hành của một nền tảng. Nếu cần xuất cho kênh cụ thể, kiểm tra yêu cầu của kênh hoặc dùng thông số người dùng cung cấp.

- Thông tin ưu đãi phải có giá/điều kiện/thời gian do người dùng xác nhận; không tự thêm “giảm 50%”, “số 1”, “100% tự nhiên”.
- Khi đổi tỷ lệ, dàn lại bố cục để chữ và món không bị cắt; không chỉ kéo giãn ảnh.
- Bàn giao ảnh PNG/JPEG phù hợp, tệp nguồn nếu có và nội dung chữ để người dùng dễ sửa. Nếu brief yêu cầu nhiều biến thể, đặt tên theo tỷ lệ hoặc mục đích.

## Bao bì, nhãn và vật phẩm tại quán

Trước khi dàn bản sản xuất, xác định vật liệu, kích thước, mặt in, khuôn bế, vùng dán/gấp và thông số từ nhà in. Với bao bì tiếp xúc thực phẩm, không tự xác nhận tính phù hợp của vật liệu khi chưa có thông tin của nhà cung cấp.

- **Mockup:** dùng để đánh giá hình thức và vị trí nhận diện. Ghi là mockup; hình phối cảnh không thay cho bản triển khai khuôn bế.
- **Bản triển khai:** dùng khuôn bế đúng phiên bản của nhà in; tách đường cắt, đường gấp và artwork theo yêu cầu của họ.
- Dùng bleed, vùng an toàn, profile CMYK, độ phân giải ảnh ở kích thước thật, màu spot và tiêu chuẩn PDF theo thông số nhà in. Không mặc định một bộ thông số phù hợp cho mọi loại bao bì.
- Mã QR phải trỏ đúng địa chỉ đã xác nhận và được thử quét ở kích thước dự kiến; barcode phải có dữ liệu hợp lệ được cung cấp, không tạo mã trang trí rồi gọi là sử dụng được.
- Nội dung nhãn như thành phần, khối lượng, hạn dùng và thông tin cơ sở phải lấy từ nguồn đã xác nhận. Chỗ thiếu được ghi rõ để người dùng hoàn thiện.

Chỉ gọi tệp là “sẵn sàng gửi in” khi đã có thông số nhà in, kiểm tra đúng kích thước/khuôn bế, font, ảnh, bleed, màu và xuất tệp. Nếu chưa đủ, bàn giao “bản thiết kế chờ xác nhận thông số in” cùng danh sách dữ liệu còn thiếu.

## Video quảng cáo món ăn và đồ uống

Lập storyboard hoặc shot list có mốc thời gian, hình ảnh, nội dung chữ, âm thanh và chuyển cảnh. Dùng cấu trúc mở đầu thu hút → món/đồ uống và điểm nổi bật đã xác nhận → lời kêu gọi hành động; điều chỉnh theo thời lượng, không kéo dài cảnh chỉ để đủ mẫu.

- Khi brief chưa chỉ định, có thể bắt đầu với video dọc 9:16, 1080 × 1920 px, dài 15–30 giây. Đây là phương án thiết kế ban đầu, không phải yêu cầu hiện hành của mọi nền tảng. Chọn tỷ lệ và tốc độ khung hình theo nơi sử dụng cùng tư liệu gốc.
- Ưu tiên cảnh món thực, thao tác chế biến hoặc phục vụ từ tư liệu được cung cấp. Tư liệu tạo mới cần giữ đúng đặc điểm sản phẩm đã xác nhận và được nhận diện là minh họa trong bàn giao.
- Chỉ dùng nhạc, lời đọc và hiệu ứng âm thanh được cung cấp hoặc có nguồn/quyền sử dụng đã xác minh; giữ ghi chú nguồn. Nếu chưa có nhạc phù hợp, bàn giao bản không nhạc hoặc ghi rõ phần âm thanh chưa hoàn thiện.
- Phụ đề và chữ trên màn hình dùng font hỗ trợ tiếng Việt, ngắt câu dễ đọc và thời gian hiển thị đủ để đọc. Giữ giá, tên món và CTA trong vùng an toàn phù hợp với giao diện kênh sử dụng; không đưa số vùng an toàn cố định như quy tắc cho mọi kênh.
- Giá, ưu đãi, thành phần và lời quảng cáo vẫn phải khớp nguồn đã xác nhận. Không tự điền dữ liệu thiếu bằng lời hứa hấp dẫn hơn.
- Bàn giao video đã render, storyboard/shot list, tệp nguồn dự án và phụ đề rời khi công cụ hỗ trợ hoặc brief yêu cầu. Ghi rõ tỷ lệ, độ phân giải, thời lượng, fps và codec thực tế; MP4 H.264/AAC là lựa chọn phổ biến khi công cụ và đầu ra yêu cầu phù hợp.
- Nếu chỉ tạo được storyboard, prompt, mã composition hoặc bản dựng chưa xuất, ghi đúng trạng thái đó. Không gọi chúng là video hoàn chỉnh và không liệt kê tệp chưa được tạo.

Xem và nghe toàn bộ bản xuất, gồm đầu/cuối video, chuyển cảnh, điểm xuất hiện chữ, phụ đề và âm thanh; kiểm tra riêng khung đại diện không đủ để xác nhận video hoạt động đúng.

## Quy cách bàn giao chung

Ghi tên tệp, mục đích, kích thước, định dạng, trạng thái và cách chỉnh sửa. Nêu tệp nào đã được tạo thực tế, tệp nào chưa có do giới hạn công cụ; không mô tả một prompt hoặc bản đặc tả như thành phẩm đã xuất. Kèm những giả định còn ảnh hưởng đến giá, nội dung hoặc sản xuất.
