# Video quảng cáo F&B

## Chọn cách thực hiện từ tài nguyên hiện có

Đọc yêu cầu, xem footage/ảnh nguồn và nhận diện thương hiệu. Kiểm tra thời lượng, kích thước, âm thanh của video bằng công cụ media. Nếu có quyền đọc repository, chỉ dùng tài nguyên liên quan đến nhiệm vụ; đừng suy đoán một video bất kỳ là footage thương hiệu đã được duyệt.

- Có footage: chọn đoạn thể hiện món rõ, dựng nhịp, thêm typography và âm thanh theo brief.
- Có ảnh: có thể tạo video từ ảnh với chuyển động camera nhẹ, lớp chữ và chuyển cảnh; mô tả đúng đây là video dựng từ ảnh.
- Cần hình mới: dùng công cụ tạo/chỉnh sửa hình phù hợp. Chỉ dùng công cụ tạo video khi công cụ đó thực sự có sẵn. Không biến yêu cầu tạo hình thành việc chỉ viết prompt.
- Có HyperFrames: dùng hướng dẫn HyperFrames/CLI hiện có trước khi viết composition hoặc render. Không giả định cú pháp, khả năng đã cài hay lệnh chưa kiểm tra.
- Thiếu công cụ hoặc dữ liệu thiết yếu: hoàn thành kịch bản/storyboard, nêu chính xác file hoặc khả năng còn thiếu, không tuyên bố đã xuất MP4.

Không yêu cầu API key nếu công cụ hiện có đã đáp ứng công việc. Chỉ dùng khóa qua cơ chế cấu hình an toàn của môi trường nếu thực sự cần, không yêu cầu gửi giá trị trong hội thoại.

## Kịch bản ngắn theo mục tiêu

Mặc định tham khảo: 15 giây, khung dọc 9:16, 1080 × 1920, 30 fps. Đây là lựa chọn triển khai khi brief chưa có thông số, không phải giới hạn bắt buộc của nền tảng.

| Khoảng thời gian | Vai trò | Ví dụ cấu trúc |
| --- | --- | --- |
| 0–3 giây | Thu hút và nhận diện món | Cận cảnh sản phẩm hoặc một thông điệp ngắn |
| 3–11 giây | Trình bày trải nghiệm/điểm nổi bật | Hai hoặc ba cảnh có lý do; thông tin đúng dữ liệu được cung cấp |
| 11–15 giây | Chốt thông điệp và hành động | Tên thương hiệu, sản phẩm, CTA; giá/ưu đãi chỉ khi đã xác nhận |

Điều chỉnh nhịp theo footage và khả năng đọc, không ép mọi video vào số cảnh cố định. Đặt một mục tiêu chính, tránh nhồi toàn bộ menu vào một video ngắn. Dùng [mẫu storyboard](../templates/storyboard.md) trước khi dựng; ghi timecode, nguồn hình, chữ và âm thanh từng cảnh.

## Dựng hình và chữ

- Tạo một hệ thống typography dùng chung với thiết kế tĩnh. Nội dung phải đọc được trên màn hình nhỏ; kiểm tra trong bản render, không chỉ trong project.
- Giữ món ăn làm điểm nhìn chính. Tránh chuyển cảnh phức tạp làm mất sản phẩm, vệt hơi nước/topping giả hoặc chuyển động méo thực phẩm.
- Crop theo vị trí món và vùng chữ. Không kéo dãn footage khác tỷ lệ; chọn crop, nền đệm hoặc bố cục khác có chủ đích.
- Giữ chữ quan trọng trong vùng an toàn theo kênh/placement được xác nhận. Khi chưa có thông số, chừa khoảng trống khỏi mép và vùng giao diện thường che; không tuyên bố đã kiểm tra trên nền tảng.
- End card phải đủ thời gian đọc. Nếu có QR, kiểm tra đích và thời gian quét phù hợp; CTA dạng đường dẫn/nút của nền tảng có thể phù hợp hơn nếu brief cho phép.

## Âm thanh và phụ đề

- Dùng nguồn nhạc/giọng đọc do người dùng cung cấp hoặc nguồn có điều kiện sử dụng phù hợp đã biết; ghi nguồn trong bàn giao. Không mặc định nhạc đang thịnh hành được phép dùng cho quảng cáo.
- Chỉ tạo giọng đọc khi cần và có công cụ hỗ trợ. Xác định ngôn ngữ, cách đọc thương hiệu và giọng mong muốn; không tự mô phỏng giọng người thật.
- Khi có voiceover, hạ nhạc nền để lời rõ; tránh clipping và đầu/cuối bị cắt đột ngột. Nghe kiểm tra nếu công cụ cho phép. Nếu chỉ đo kỹ thuật, nói rõ chưa đánh giá bằng nghe.
- Phụ đề tiếng Việt cần đúng dấu, tên món và lời nói; kiểm tra timecode, nhịp đọc và xuống dòng. Không coi transcript tự động là bản đã xác nhận.
- Tệp SRT riêng hữu ích khi có lời nói và người dùng cần; bản burn-in là lựa chọn theo yêu cầu. Chữ quảng cáo trên màn hình không tự động là phụ đề của lời nói.
- Nếu không có nguồn âm thanh phù hợp, có thể dựng bản không tiếng theo brief/giả định được nêu rõ; không chèn âm thanh không rõ nguồn để lấp chỗ trống.

## Xuất và kiểm tra

Định dạng xem phổ biến: MP4, H.264, pixel format yuv420p; AAC nếu có âm thanh. Dùng yêu cầu thực tế của nơi phát hành nếu đã biết. Giữ project/composition và tài nguyên phụ thuộc để có thể sửa lại; không gọi MP4 là file nguồn có thể chỉnh từng lớp.

Nếu FFmpeg/ffprobe có sẵn, kiểm tra trên đường dẫn thực tế, ví dụ:

```bash
ffprobe -v error -show_entries format=duration,size:stream=codec_type,codec_name,width,height,pix_fmt,r_frame_rate -of json /duong-dan-thuc-te/video.mp4
ffmpeg -nostdin -v error -xerror -i /duong-dan-thuc-te/video.mp4 -f null -
```

Các đường dẫn trên là mẫu cần thay, không phải file đã tồn tại. Giữ nguyên mã thoát của lệnh. Giải mã thành công chứng minh file đọc được, không chứng minh thông điệp, chữ hay âm thanh đã đúng.

Xem video từ đầu tới cuối nếu công cụ cho phép. Nếu chỉ xem được khung hình, kiểm tra đầu/cuối, mọi cảnh và điểm chuyển; báo rõ giới hạn này. Kiểm tra không có cảnh đen ngoài ý muốn, chữ bị cắt, phụ đề quá nhanh, âm thanh lệch hoặc CTA biến mất trước khi đọc xong. Dùng thêm checklist trong [review-checklist.md](review-checklist.md).

Bàn giao MP4, bản xem thực tế, phụ đề nếu có, project/composition nếu đã tạo và danh sách nguồn tài nguyên. Ghi thông số đo được cùng bước kiểm tra thực sự đã thực hiện; không báo video đã đăng hoặc đã duyệt bởi nền tảng.
