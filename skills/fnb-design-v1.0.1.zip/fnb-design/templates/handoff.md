# Bàn giao thiết kế

**Thương hiệu / đầu ra:** [Tên]

**Phiên bản:** [v01]

**Hướng thiết kế:** [Một hoặc hai câu gắn với khách hàng và mục tiêu.]

## Tệp

| Tệp / đường dẫn | Vai trò | Kích thước / định dạng | Trạng thái |
| --- | --- | --- | --- |
| [Đường dẫn thật] | [Bản xem / file xuất / file nguồn / mockup] | [Thông số đo được] | [Đã kiểm tra / còn chờ] |

## Hệ thống hình ảnh

- Màu và vai trò: [Nền / chữ / nhấn; mã màu thực tế].
- Chữ: [Họ font, độ đậm, cấp bậc; nêu font thay thế nếu đã dùng].
- Hình ảnh và logo: [Nguồn, phần đã chỉnh, phần là minh họa].
- Video nếu có: [Thời lượng thực tế, tỷ lệ, fps, codec; nguồn footage/âm thanh; file phụ đề và project].

## Kiểm tra đã thực hiện

[Ghi thao tác và kết quả thật: mở/render, kích thước, chữ tiếng Việt, giá, QR, vùng cắt. Với video: giải mã, các cảnh đã xem, thời gian đọc chữ/phụ đề và âm thanh đã nghe nếu có khả năng. Không đánh dấu kiểm tra chưa chạy.]

## Phần còn chờ

[Placeholder cụ thể hoặc xác nhận của người dùng/nhà in. Nếu không còn, ghi “Không có trong phạm vi đã kiểm tra”.]

**Mức hoàn tất:** [Concept / bản số đã kiểm tra / chờ preflight in / file in đã được kiểm tra theo thông số được cung cấp].
