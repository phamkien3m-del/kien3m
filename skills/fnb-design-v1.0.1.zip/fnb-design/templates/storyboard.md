# Storyboard video F&B

**Thương hiệu / món chủ lực:** [Tên chính xác]

**Mục tiêu và CTA:** [Một mục tiêu, một hành động chính]

**Đầu ra:** [Thời lượng, tỷ lệ, kích thước, fps, định dạng]

**Tài nguyên:** [Footage/ảnh/logo/nhạc/giọng đọc; đường dẫn thật hoặc trạng thái còn thiếu]

**Hướng hình ảnh:** [Ánh sáng, màu, typography, nhịp]

| Cảnh | Bắt đầu–kết thúc | Hình và chuyển động | Nguồn tài nguyên | Chữ trên màn hình | Lời đọc / âm thanh |
| --- | --- | --- | --- | --- | --- |
| 1 | [0–3s, ví dụ] | [Hook và món chủ lực] | [File hoặc cần tạo] | [Nội dung chính xác] | [Nếu có] |
| 2 | [3–7s, ví dụ] | [Chi tiết sản phẩm] | [File hoặc cần tạo] | [Nội dung chính xác] | [Nếu có] |
| 3 | [7–11s, ví dụ] | [Trải nghiệm/điểm nổi bật] | [File hoặc cần tạo] | [Nội dung chính xác] | [Nếu có] |
| 4 | [11–15s, ví dụ] | [End card] | [Logo/ảnh] | [CTA, giá nếu đã xác nhận] | [Kết âm] |

Điều chỉnh số cảnh và mốc thời gian theo brief. Các đoạn không được có khoảng trống/vượt thời lượng ngoài ý muốn. Thời lượng cần đủ đọc chữ và lời, không chỉ cộng đúng số giây.

## Phụ đề

[Có/không; ngôn ngữ; burn-in hay SRT; nguồn transcript; cách đọc tên thương hiệu.]

## Điểm còn chờ

[CẦN XÁC NHẬN: thông tin hoặc tài nguyên thực sự thiếu.]

## Kiểm tra xuất

[Thông số đo được; giải mã; các cảnh đã xem; chữ/phụ đề; âm thanh; giới hạn chưa kiểm tra.]
