# Chỉ dẫn hình ảnh F&B

Dùng để điều khiển công cụ tạo/chỉnh sửa hình. Không đưa placeholder thương mại lên ảnh cuối. Với việc chỉnh sửa, xem ảnh nguồn trước và chỉ thay đổi những phần người dùng yêu cầu.

## Nội dung chỉ dẫn

> Tạo [loại hình: ảnh chụp phong cách studio / minh họa / key visual] cho [loại thương hiệu và khách hàng]. Chủ thể chính là [món/đồ uống và đặc điểm thật đã biết]. Bố cục [vị trí, hướng nhìn, khoảng trống cho chữ]. Ánh sáng [nguồn, độ mềm, thời điểm]; bảng màu [vai trò các màu]; bề mặt/phông nền [chất liệu]. Giữ [chi tiết bắt buộc của sản phẩm/ảnh tham chiếu]. Tỷ lệ khung [x:y], kích thước mục tiêu [rộng × cao nếu công cụ hỗ trợ]. Tránh [chỉ những chi tiết gây sai sản phẩm hoặc trái brief].

## Chữ và thành phần thương mại

- Nội dung chữ chính xác: [văn bản được xác nhận]. Nếu dùng lớp chữ riêng, yêu cầu ảnh chừa vùng sạch và không tự thêm chữ.
- Logo: dùng tài nguyên thương hiệu đã cung cấp, giữ tỷ lệ và vùng trống.
- Giá, ưu đãi, hotline, địa chỉ: lấy từ brief, kiểm tra lần cuối trên file xuất.
- QR: tạo từ đích được xác nhận bằng công cụ QR, kiểm tra giải mã; không dùng hình QR trang trí do công cụ tạo ảnh tưởng tượng.

## Phân biệt minh họa và sản phẩm thật

Ảnh concept phải được ghi là minh họa trong bàn giao. Không tự thêm topping, nguyên liệu, chứng nhận, kích cỡ phần ăn hoặc chi tiết bao bì khiến khách hiểu sai sản phẩm. Không khẳng định “không gây dị ứng” từ hình ảnh hoặc phỏng đoán thành phần.
