# Brief thiết kế F&B

Điền từ thông tin đã có trước. Chỉ hỏi người dùng phần còn thiếu có ảnh hưởng đến đầu ra.

| Mục | Nội dung |
| --- | --- |
| Thương hiệu / loại hình | [Tên quán, sản phẩm, mô hình phục vụ] |
| Đầu ra | [Nhận diện / menu / bao bì / bài đăng / video / bộ chiến dịch] |
| Mục tiêu và hành động | [Khách cần hiểu gì, làm gì sau khi xem] |
| Khách hàng chính | [Thói quen, bối cảnh mua, mức chi tiêu nếu đã biết] |
| Món hoặc sản phẩm chủ lực | [Tên chính xác, điểm khác biệt có căn cứ] |
| Nội dung đã xác nhận | [Tên món, mô tả, giá, tiền tệ, địa chỉ, ưu đãi, thời hạn] |
| Tài nguyên | [Logo, ảnh, nhận diện cũ, font, quyền sử dụng đã biết] |
| Hướng cảm xúc | [Mộc mạc / năng động / tối giản / khác; có ví dụ nếu có] |
| Kênh và kích thước | [Nơi dùng, chiều rộng × chiều cao, đơn vị, số trang/mặt] |
| Định dạng bàn giao | [PNG / PDF / SVG / file nguồn theo công cụ thực tế] |
| Video nếu có | [Thời lượng, fps, footage, giọng đọc, âm nhạc, phụ đề, CTA cuối] |
| Yêu cầu sản xuất | [Dieline, khổ in, chất liệu, bleed, profile màu nếu có] |
| Hạn chế và ưu tiên | [Điều phải giữ, điều tránh, thời hạn] |

## Giả định có thể triển khai

[Các quyết định thẩm mỹ hoặc kích thước mặc định; không ghi dữ liệu kinh doanh bịa đặt ở đây.]

## Thông tin còn chờ

[CẦN XÁC NHẬN: giá / nội dung / tài nguyên còn thiếu.]

## Tiêu chí hoàn tất

[Ví dụ: một menu đúng danh sách món và giá đã cung cấp, đọc được ở khổ A4, có bản PDF để xem và file nguồn thực tế, không còn placeholder. Nếu chưa có yêu cầu nhà in thì chưa gắn trạng thái sẵn sàng in.]
